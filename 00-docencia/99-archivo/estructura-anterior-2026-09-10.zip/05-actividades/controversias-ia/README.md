# Prototipos de controversias con respuestas de IA

Estos expedientes desarrollan capacidades para debatir, verificar y delimitar respuestas de inteligencia artificial antes de trabajar en vivo con una plataforma.

## Prototipos

1. `01-germinacion-y-causalidad.qmd`: distinguir resultado observado e inferencia causal.
2. `02-controlar-todas-las-variables.qmd`: hacer visibles supuestos y consecuencias del ajuste.
3. `03-muchas-observaciones-pocas-replicas.qmd`: reconocer unidades experimentales y pseudorreplicación.

`guia-docente-controversias.qmd` contiene propósitos, secuencia de revelación y criterios de observación.

## Naturaleza de las respuestas

Las “respuestas de IA” fueron redactadas deliberadamente para el curso. No representan una plataforma o modelo específico. Combinan elementos correctos, plausibles, incompletos y problemáticos para sostener una deliberación auténtica.

## Protocolo común

1. afirmación exacta;
2. estatus epistemológico;
3. supuesto necesario;
4. evidencia disponible;
5. explicación alternativa;
6. prueba o contraste;
7. decisión provisional;
8. grado de confianza.

Las actividades pueden realizarse sin acceso en vivo a IA. Una comparación posterior con respuestas de plataformas reales es opcional.
