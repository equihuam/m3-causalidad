# Prototipos de talleres en RStudio

Esta carpeta contiene una introducción a Dagitty y tres prototipos para probar el formato didáctico:

1. `00-introduccion-dagitty-web-r.qmd`
2. `01-factorial-completamente-aleatorizado.qmd`
3. `02-bloques-aleatorizados.qmd`
4. `03-parcela-dividida.qmd`

Cada actividad produce un minirreporte Quarto con la misma estructura:

1. pregunta causal;
2. predicción previa;
3. diseño y unidades;
4. resultados;
5. interpretación;
6. límites y transferencia.

La repetición de la estructura es deliberada. Se busca que Quarto reduzca la fragmentación entre código, resultados y argumento sin convertirse en un objetivo técnico independiente.

El archivo `guia-docente-prototipos.qmd` contiene soluciones orientativas, errores productivos y criterios para observar el funcionamiento de los talleres.

## Dependencias

Los prototipos utilizan paquetes disponibles en la instalación revisada:

- `ggplot2`;
- `dagitty`;
- `nlme`, solamente para parcela dividida.

Las simulaciones se generan dentro de cada documento; no requieren archivos de datos externos.

## Uso sugerido

- entregar al estudiante una copia del `.qmd`;
- pedir que escriba la predicción antes de ejecutar la simulación completa;
- trabajar en parejas, alternando quién conduce RStudio y quién audita las decisiones;
- liberar pistas de manera escalonada;
- consolidar la solución después del intento;
- evaluar el razonamiento, no la decoración del documento.

## Reproducibilidad integrada

Desde la revisión del 10 de septiembre de 2026 se conserva la estructura del minirreporte y se adjunta la [ficha de entrega reproducible](../../03-materiales-estudiantes/ficha-entrega-reproducible.qmd). El factorial será el caso común para un futuro flujo pequeño de Snakemake; los Quarto actuales no constituyen todavía ese pipeline.

Una semilla dentro del documento facilita repetir la simulación, pero se deben conservar configuración, código y entorno, y comprobar ejecución desde una sesión nueva. La [auditoría por pares](../auditoria-reproducibilidad-analitica.qmd) utiliza una copia completada por estudiantes, no la hoja original con consignas pendientes. El entorno de paquetes debe verificarse antes del curso; la lista histórica anterior no garantiza su disponibilidad en otro equipo.
