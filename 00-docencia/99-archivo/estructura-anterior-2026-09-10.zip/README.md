# M3 Causalidad, diseño experimental e IA

Repositorio para diseñar, desarrollar y organizar un curso intensivo sobre teoría causal, diseño experimental e inteligencia artificial.

## Estructura de carpetas

- `00-bitacora/`: bitácora del responsable del curso sobre sus decisiones de diseño; distingue decisiones adoptadas y propuestas del asistente.
- `01-diseno-curso/`: diseño general, planificación y secuencia del curso.
- `02-materiales-docente/`: materiales de apoyo para el equipo docente.
- `03-materiales-estudiantes/`: materiales destinados a estudiantes.
- `04-guias-cheatsheets/`: guías breves y hojas de consulta rápida.
- `05-actividades/`: actividades, ejercicios y dinámicas de aprendizaje.
- `06-rubricas/`: criterios e instrumentos de evaluación.
- `07-ejemplos/`: ejemplos, casos y demostraciones.
- `99-archivo/`: materiales archivados o fuera de uso activo.

El contenido se desarrollará de manera incremental.

## Dos bitácoras con funciones distintas

- [Bitácora de decisiones de diseño del curso](00-bitacora/bitacora-maestra.qmd): registra lo que decide el responsable del curso, sus motivos, fuente y estado. El asistente puede mantenerla sin atribuirle propuestas propias.
- [Guía de bitácora analítica del estudiante](03-materiales-estudiantes/guia-bitacora-analitica.qmd): explica dónde escribir, cuándo registrar y cómo vincular decisiones, versiones, ejecuciones y resultados. Incluye plantilla y ejemplo. Cada estudiante o equipo lleva su propia copia en su proyecto.
- [Guía docente para enseñarla](02-materiales-docente/ensenar-bitacora-analitica.qmd).

## Programa y materiales

- [Secuencia de nueve días](01-diseno-curso/contenido-tematico-y-experiencia-de-aprendizaje.qmd).
- [Reproducibilidad: competencia, progresión e inventario por carpeta](01-diseno-curso/competencia-reproducibilidad-analitica.qmd).
- [Rúbrica del proyecto, reflexión y anexo reproducible](06-rubricas/rubrica-proyecto-y-reflexion.qmd).
- [Ficha estudiantil de entrega y reconstrucción](03-materiales-estudiantes/ficha-entrega-reproducible.qmd).
- [Auditoría de reproducibilidad por pares](05-actividades/auditoria-reproducibilidad-analitica.qmd).

La revisión del 10 de septiembre de 2026 integra reproducibilidad durante los nueve días. RStudio y Quarto siguen como base; el ejemplo Snakemake y su entorno restaurable están pendientes de implementación y piloto en `07-ejemplos/`. Los `.qmd` son las fuentes editables; los HTML son salidas de consulta. Los antecedentes PDF, XLSX y archivados se conservan.
