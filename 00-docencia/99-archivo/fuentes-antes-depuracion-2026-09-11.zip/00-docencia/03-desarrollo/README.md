# Materiales en desarrollo

Esta carpeta reúne desarrollos que todavía no forman parte del paquete estudiantil. El piloto de Snakemake requiere un ejemplo ejecutable, scripts de R separados, configuración, entorno restaurable, resultados de referencia y pruebas de reconstrucción y cambio.

El requisito curricular está descrito en la [competencia de reproducibilidad](../01-diseno-curso/competencia-reproducibilidad-analitica.qmd). La reestructuración de carpetas no implementa ese ejemplo ni certifica su funcionamiento.

Cuando un material esté preparado y comprobado, ubicar su versión de entrega en el apartado estudiantil correspondiente —o crear `01-estudiantes/05-ejemplos/` si se trata de ejemplos ejecutables independientes— y conservar aquí sólo instrucciones de desarrollo y validación para instructores. Actualizar el índice de entrega y comprobar que no dependa de archivos docentes.
