# Talleres en RStudio

Trabaja en parejas y escribe tu predicción antes de ejecutar el código. Alternen quién conduce RStudio y quién revisa las decisiones.

1. [Introducción a Dagitty: web y R](00-introduccion-dagitty-web-r.qmd).
2. [Factorial completamente aleatorizado](01-factorial-completamente-aleatorizado.qmd).
3. [Bloques aleatorizados](02-bloques-aleatorizados.qmd).
4. [Parcela dividida](03-parcela-dividida.qmd).

Cada taller incluye código guiado y preguntas que debes completar. Conserva seis componentes en el minirreporte: pregunta, predicción, diseño y unidades, resultados, interpretación y límites. El código de ejemplo forma parte de la práctica; no sustituye tus decisiones ni tu explicación.

Necesitas R, RStudio y Quarto; los talleres utilizan `ggplot2`, `dagitty` y, para parcela dividida, `nlme`. El equipo docente indicará el entorno preparado para la clase. Las simulaciones se generan dentro de los documentos y no necesitan datos externos.

Lleva tu [bitácora analítica](../../01-guias/guia-bitacora-analitica.qmd) y completa la [ficha de reconstrucción](../../01-guias/ficha-entrega-reproducible.qmd). Comprueba el documento desde una sesión nueva y conserva la versión utilizada. Una semilla no reemplaza el registro de código, parámetros y entorno.

[Volver a actividades](../README.md).
