# Causalidad, diseño experimental e inteligencia artificial

Este paquete reúne los materiales para tu trabajo durante el curso intensivo de nueve días. Puedes conservarlo completo en tu equipo; sus enlaces locales se mantienen dentro de este paquete.

## Por dónde empezar

1. Lee el [programa del curso y los objetivos de aprendizaje](00-curso/programa-del-curso.qmd).
2. Inicia tu [bitácora analítica](01-guias/guia-bitacora-analitica.qmd) y conserva la primera versión de tu pregunta.
3. Consulta las [actividades](02-actividades/README.md) y realiza las que correspondan a la sesión.
4. Revisa las [lecturas](03-lecturas/README.md) y los [criterios de evaluación](04-evaluacion/rubrica-proyecto-y-reflexion.qmd).
5. Prepara la entrega con la [ficha de reconstrucción del análisis](01-guias/ficha-entrega-reproducible.qmd).

## Qué encontrarás

| Carpeta | Para qué usarla |
|---|---|
| `00-curso/` | Descripción del curso, objetivos, recorrido de nueve días y productos |
| `01-guias/` | Bitácora, continuidad del trabajo con IA gratuita y entrega reproducible |
| `02-actividades/` | Auditorías, ejercicios, talleres RStudio y controversias |
| `03-lecturas/` | Lecturas del curso y preguntas para relacionarlas con tu proyecto |
| `04-evaluacion/` | Criterios, niveles de desempeño y autoevaluación |

Los archivos `.qmd` son documentos Quarto editables. Los `.html` permiten leer las versiones renderizadas en un navegador; conserva sus carpetas auxiliares `_files` si las hay. Los talleres incluyen código guiado y espacios que debes completar; el equipo docente indicará el orden y el entorno de ejecución.

No necesitas servicios de pago ni una consulta nueva a IA para continuar el trabajo. La [guía de continuidad](01-guias/guia-continuidad-ia-free-tier.qmd) explica cómo conservar el contexto y seguir con archivos locales o revisión por pares.
